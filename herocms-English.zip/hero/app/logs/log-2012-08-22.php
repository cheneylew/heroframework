<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-08-22 00:00:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:01:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:01:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:01:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:01:17 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:01:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:09:14 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:09:14 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:09:21 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:09:21 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:10:45 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:10:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:10:54 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:10:54 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:11:48 --> 404 Page Not Found --> product/eng_product2
ERROR - 2012-08-22 00:14:55 --> Severity: Notice  --> Undefined index: month /var/www/html/hero/writeable/templates_compile/e5dd7a9d39477df9f969befdcc1ffa5813425c79.file.events.thtml.php 199
ERROR - 2012-08-22 00:14:59 --> Severity: Notice  --> Undefined variable: gallery /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:15:00 --> Severity: Notice  --> Undefined index: month /var/www/html/hero/writeable/templates_compile/e5dd7a9d39477df9f969befdcc1ffa5813425c79.file.events.thtml.php 199
ERROR - 2012-08-22 00:15:01 --> Severity: Notice  --> Undefined variable: gallery /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:15:02 --> 404 Page Not Found --> about_us
ERROR - 2012-08-22 00:15:04 --> Severity: Notice  --> Undefined index: month /var/www/html/hero/writeable/templates_compile/e5dd7a9d39477df9f969befdcc1ffa5813425c79.file.events.thtml.php 199
ERROR - 2012-08-22 00:15:13 --> Severity: Notice  --> Undefined index: month /var/www/html/hero/writeable/templates_compile/e5dd7a9d39477df9f969befdcc1ffa5813425c79.file.events.thtml.php 199
ERROR - 2012-08-22 00:15:22 --> Severity: Notice  --> Undefined variable: gallery /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:15:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:15:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:16:00 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:16:00 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 00:16:02 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 00:16:02 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 01:22:34 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:22:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:24:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:24:10 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:24:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:24:16 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:24:16 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:24:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:30:17 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:30:17 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:48:31 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:48:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:49:16 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:49:16 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:49:22 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:49:22 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:58:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 01:58:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 02:02:17 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 02:02:17 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 02:31:49 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 02:31:49 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 03:15:13 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 03:15:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 05:54:18 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 05:54:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:00:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:00:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:01:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:01:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:02:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:02:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:03:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:03:27 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:03:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:03:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:04:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:04:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:05:33 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:05:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:06:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:06:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:06:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:07:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:08:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:08:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:52:13 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:52:13 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:52:22 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:52:22 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:52:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:52:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:52:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:53:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:53:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-22 06:53:35 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:53:35 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:53:47 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:53:48 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:56:00 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:56:00 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-22 06:59:24 --> Severity: Notice  --> Undefined variable: gallery /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
