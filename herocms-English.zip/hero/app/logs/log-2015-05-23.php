<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-23 10:22:31 --> Severity: Notice  --> unserialize() [<a href='function.unserialize'>function.unserialize</a>]: Error at offset 0 of 1 bytes /Applications/MAMP/htdocs/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
