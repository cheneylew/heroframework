ERROR - 2012-08-21 07:09:23 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 07:11:22 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:11:22 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:18:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:18:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:19:01 --> Severity: Notice  --> Undefined index: language_name /var/www/html/hero/app/modules/publish/models/content_model.php 735
ERROR - 2012-08-21 07:19:01 --> Severity: Notice  --> Undefined index: language_name /var/www/html/hero/app/modules/publish/models/content_model.php 735
ERROR - 2012-08-21 07:19:01 --> Severity: Notice  --> Undefined index: language_name /var/www/html/hero/app/modules/publish/models/content_model.php 735
ERROR - 2012-08-21 07:19:01 --> Severity: Notice  --> Undefined index: language_name /var/www/html/hero/app/modules/publish/models/content_model.php 735
ERROR - 2012-08-21 07:19:01 --> Severity: Notice  --> Undefined index: language_name /var/www/html/hero/app/modules/publish/models/content_model.php 735
ERROR - 2012-08-21 07:19:01 --> Severity: Notice  --> Undefined index: language_name /var/www/html/hero/app/modules/publish/models/content_model.php 735
ERROR - 2012-08-21 07:19:01 --> Severity: Notice  --> Undefined index: language_name /var/www/html/hero/app/modules/publish/models/content_model.php 735
ERROR - 2012-08-21 07:26:31 --> Severity: Notice  --> Undefined variable: result /var/www/html/hero/app/modules/publish/models/content_model.php 335
ERROR - 2012-08-21 07:27:05 --> Query error: Unknown column 'language.language_id' in 'on clause'
ERROR - 2012-08-21 07:27:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:27:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:29:13 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:29:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:29:21 --> Severity: Warning  --> Missing argument 2 for CI_DB_active_record::join(), called in /var/www/html/hero/app/modules/forms/models/form_model.php on line 223 and defined /var/www/html/hero/system/database/DB_active_rec.php 310
ERROR - 2012-08-21 07:29:21 --> Severity: Notice  --> Undefined variable: cond /var/www/html/hero/system/database/DB_active_rec.php 331
ERROR - 2012-08-21 07:29:21 --> Severity: Notice  --> Undefined variable: cond /var/www/html/hero/system/database/DB_active_rec.php 340
ERROR - 2012-08-21 07:29:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LEFT JOIN `forms` ON `forms`.`link_id`="`27"`
JOIN `links` ON 
WHERE `links`.`li' at line 2
ERROR - 2012-08-21 07:29:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`
WHERE `links`.`link_id` =  '27'' at line 3
ERROR - 2012-08-21 07:30:36 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/forms/models/form_model.php 237
ERROR - 2012-08-21 07:31:21 --> Query error: Table 'hero.language' doesn't exist
ERROR - 2012-08-21 07:33:29 --> Query error: Table 'hero.language' doesn't exist
ERROR - 2012-08-21 07:35:03 --> Severity: Notice  --> Undefined index: language_id /var/www/html/hero/app/models/language_model.php 73
ERROR - 2012-08-21 07:35:03 --> Severity: Notice  --> Undefined index: language_id /var/www/html/hero/app/models/language_model.php 73
ERROR - 2012-08-21 07:35:03 --> Severity: Notice  --> Undefined index: language_id /var/www/html/hero/app/models/language_model.php 73
ERROR - 2012-08-21 07:35:17 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:35:17 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:35:18 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:35:18 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:35:19 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:35:19 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:35:20 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:35:20 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:35:33 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:35:33 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:35:59 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:35:59 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:36:10 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:36:10 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:37:23 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:37:23 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:37:51 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:37:51 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:38:27 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:38:27 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:38:28 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:38:28 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:38:34 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:38:35 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:38:35 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:38:35 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:38:43 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:38:43 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:38:44 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:38:44 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:38:52 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:38:52 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:38:52 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/forms/models/form_model.php 192
ERROR - 2012-08-21 07:38:52 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:40:48 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:41:48 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:41:53 --> 404 Page Not Found --> contact_us
ERROR - 2012-08-21 07:42:24 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/hero/app/modules/publish/models/content_model.php 300
ERROR - 2012-08-21 07:42:24 --> 404 Page Not Found --> about_us
ERROR - 2012-08-21 07:42:49 --> Severity: Notice  --> Undefined variable: product_name /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 07:42:51 --> 404 Page Not Found --> about_us
ERROR - 2012-08-21 07:42:53 --> Severity: Notice  --> Undefined variable: product_name /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 07:42:54 --> 404 Page Not Found --> about_us
ERROR - 2012-08-21 07:43:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:43:16 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:43:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:44:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:44:17 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:44:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:44:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:45:20 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:45:20 --> Severity: Notice  --> Undefined index: content_id /var/www/html/hero/app/modules/publish/views/create_post.php 38
ERROR - 2012-08-21 07:45:20 --> Severity: Notice  --> Undefined index: content_id /var/www/html/hero/app/modules/publish/views/create_post.php 38
ERROR - 2012-08-21 07:45:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:45:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:45:40 --> Severity: Notice  --> Undefined index: content_id /var/www/html/hero/app/modules/publish/views/create_post.php 38
ERROR - 2012-08-21 07:45:40 --> Severity: Notice  --> Undefined index: content_id /var/www/html/hero/app/modules/publish/views/create_post.php 38
ERROR - 2012-08-21 07:46:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:46:24 --> Severity: Notice  --> Undefined index: content_id /var/www/html/hero/app/modules/publish/views/create_post.php 38
ERROR - 2012-08-21 07:46:24 --> Severity: Notice  --> Undefined index: content_id /var/www/html/hero/app/modules/publish/views/create_post.php 38
ERROR - 2012-08-21 07:47:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:47:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 07:47:14 --> Severity: Notice  --> Undefined index: form_id /var/www/html/hero/app/modules/forms/views/form.php 52
ERROR - 2012-08-21 07:49:20 --> Severity: Notice  --> Undefined variable: field_name /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/member_group_relationship.php 230
ERROR - 2012-08-21 07:49:55 --> Severity: Notice  --> Undefined index: field_name /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 231
ERROR - 2012-08-21 07:49:55 --> Severity: Notice  --> Undefined index: content_type /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 232
ERROR - 2012-08-21 07:49:55 --> Severity: Notice  --> Undefined index: allow_multiple /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 233
ERROR - 2012-08-21 07:50:08 --> Severity: Notice  --> Undefined index: field_name /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 231
ERROR - 2012-08-21 07:50:08 --> Severity: Notice  --> Undefined index: content_type /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 232
ERROR - 2012-08-21 07:50:08 --> Severity: Notice  --> Undefined index: allow_multiple /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 233
ERROR - 2012-08-21 07:50:13 --> Severity: Notice  --> Undefined variable: field_name /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/member_group_relationship.php 230
ERROR - 2012-08-21 07:50:28 --> Severity: Notice  --> Undefined index: height /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/textarea.php 265
ERROR - 2012-08-21 07:50:40 --> Severity: Notice  --> Undefined index: height /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/textarea.php 265
ERROR - 2012-08-21 07:50:59 --> Severity: Notice  --> Undefined index: height /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/textarea.php 265
ERROR - 2012-08-21 07:52:47 --> Severity: Notice  --> Undefined index: allow_multiple /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/topic_relationship.php 223
ERROR - 2012-08-21 07:52:53 --> Severity: Notice  --> Undefined index: field_name /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 231
ERROR - 2012-08-21 07:52:53 --> Severity: Notice  --> Undefined index: content_type /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 232
ERROR - 2012-08-21 07:52:53 --> Severity: Notice  --> Undefined index: allow_multiple /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 233
ERROR - 2012-08-21 08:04:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:04:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:05:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:05:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:06:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:06:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:07:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:07:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:07:28 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:07:28 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:07:41 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:07:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:08:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:08:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:08:58 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:09:05 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:09:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:09:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:09:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:09:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:10:34 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:10:52 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:10:56 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:12:55 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:12:56 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:13:03 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:13:05 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:14:43 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:14:54 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:15:19 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:15:52 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:16:34 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:16:35 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:16:43 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:16:44 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:17:29 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:17:29 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:17:32 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:17:33 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:17:33 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:17:37 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:17:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:18:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:18:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:19:37 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:19:39 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:19:40 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:20:39 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:20:53 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:20:54 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:21:07 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:21:08 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:21:17 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:21:18 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:21:56 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:21:57 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:22:01 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:22:54 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:27:00 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:29:08 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:29:24 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:29:25 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:29:29 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:29:30 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:29:39 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:29:40 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:30:10 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:30:32 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:31:36 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:31:54 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:32:25 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:32:44 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:32:45 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:33:15 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:33:53 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:35:32 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:35:38 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:39:37 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:40:02 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:41:13 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:41:48 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:41:48 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:41:48 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:41:57 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:41:57 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:41:59 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:41:59 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:42:29 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:42:29 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:42:35 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:42:35 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:42:47 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:42:47 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:43:07 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:43:07 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:44:31 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:44:31 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:45:09 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:45:30 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:45:30 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:45:40 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:45:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 08:45:46 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:45:58 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:45:58 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:46:29 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:49:13 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:49:13 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:49:56 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:49:56 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:49:59 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:49:59 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:50:00 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:50:00 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:50:44 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:50:44 --> No field data was passed to Fieldtype::load().
ERROR - 2012-08-21 08:50:55 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:05 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:05 --> Severity: Notice  --> Undefined variable: field /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:20 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:20 --> Severity: Notice  --> Undefined variable: field /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:20 --> Severity: Notice  --> Undefined variable: field /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:24 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:24 --> Severity: Notice  --> Undefined variable: field /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:24 --> Severity: Notice  --> Undefined variable: field /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:43 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:43 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:47 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:52:47 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:57:34 --> Severity: Notice  --> Undefined index: custom_field_group_id /var/www/html/hero/app/modules/publish/controllers/content.php 71
ERROR - 2012-08-21 08:57:34 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:57:34 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:59:01 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/modules/publish/controllers/content.php 72
ERROR - 2012-08-21 08:59:01 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:59:01 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:59:21 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:59:21 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:59:55 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 08:59:55 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:00:00 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:00:00 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:01:11 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:01:11 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:02:14 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:02:14 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:02:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:02:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:05:25 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:05:25 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:00 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:00 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:18 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:18 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:29 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:29 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:06:53 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:07:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:38 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:38 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:11:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 105
ERROR - 2012-08-21 09:11:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multiselect.php 102
ERROR - 2012-08-21 09:12:15 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:12:15 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:12:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 105
ERROR - 2012-08-21 09:12:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multiselect.php 102
ERROR - 2012-08-21 09:12:31 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:12:31 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:12:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 105
ERROR - 2012-08-21 09:12:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multiselect.php 102
ERROR - 2012-08-21 09:13:37 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:13:37 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:13:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 105
ERROR - 2012-08-21 09:13:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multiselect.php 102
ERROR - 2012-08-21 09:13:55 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:13:55 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:13:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 105
ERROR - 2012-08-21 09:13:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 14 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multiselect.php 102
ERROR - 2012-08-21 09:14:13 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:14:13 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:15:14 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:15:14 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:16:21 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:16:21 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:17:36 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:17:36 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:18:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:18:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:20:30 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:20:30 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:21:20 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:21:42 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:21:42 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:22:12 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:22:12 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:23:03 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:23:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:23:23 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:23:23 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:25:06 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:25:06 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:25:08 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:25:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:26:40 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:26:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:26:47 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:26:47 --> Severity: Notice  --> Undefined offset: 1 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 137
ERROR - 2012-08-21 09:26:47 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:26:56 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:26:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:27:06 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:27:06 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:27:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:27:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:27:45 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:27:45 --> Severity: Notice  --> Undefined offset: 1 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 137
ERROR - 2012-08-21 09:27:45 --> Severity: Notice  --> Undefined offset: 1 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 137
ERROR - 2012-08-21 09:27:45 --> Severity: Notice  --> Undefined offset: 1 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 137
ERROR - 2012-08-21 09:27:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:27:55 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:27:55 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:28:58 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:28:58 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:29:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:29:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:32:17 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:32:17 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:33:47 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:33:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:34:23 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:34:23 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:35:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:35:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:37:14 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:37:14 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:44:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:44:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:44:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:44:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:45:07 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:45:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:45:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:45:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:46:33 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:46:33 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:46:35 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:46:35 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:47:41 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:47:41 --> Severity: Notice  --> Undefined variable: list /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 151
ERROR - 2012-08-21 09:47:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 151
ERROR - 2012-08-21 09:47:41 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:47:50 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:48:42 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:48:46 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:48:46 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 09:50:03 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:50:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:50:45 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:50:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:51:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:51:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:52:18 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:52:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:52:29 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:52:29 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:52:55 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:52:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:53:32 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:53:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:53:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:53:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:54:05 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:54:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:54:34 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:54:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:55:16 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:55:16 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:55:40 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:55:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:56:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:56:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:58:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:58:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:58:51 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:58:51 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:58:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:58:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:59:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 09:59:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:00:58 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:00:58 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:01:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:01:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:02:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:02:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:02:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:02:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:02:19 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:02:19 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:02:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:02:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:03:29 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:03:29 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:03:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:03:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:04:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:04:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:04:05 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:04:05 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:05:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:05:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:07:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:07:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:07:29 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:07:29 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:08:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:08:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:09:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:09:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:09:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:09:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:09:35 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:09:35 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:09:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:09:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:10:27 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:10:27 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:10:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:10:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:11:22 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:11:22 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:11:32 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:11:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:11:35 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:11:35 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:14:13 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:14:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:14:52 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:14:52 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:14:58 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:14:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:15:44 --> 404 Page Not Found --> product/eng_product2
ERROR - 2012-08-21 10:15:46 --> 404 Page Not Found --> product/eng_product2
ERROR - 2012-08-21 10:15:48 --> 404 Page Not Found --> product/eng_product2
ERROR - 2012-08-21 10:15:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:15:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:15:57 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:15:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:16:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:16:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:17:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:17:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:17:47 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:17:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:17:53 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:17:53 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:18:17 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:18:17 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:19:29 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:19:29 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:21:04 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:21:04 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:21:51 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:21:51 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:21:58 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:21:58 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:22:19 --> 404 Page Not Found --> product/eng_product2
ERROR - 2012-08-21 10:22:22 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:22:22 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:25:00 --> 404 Page Not Found --> product/eng_product2
ERROR - 2012-08-21 10:25:50 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:25:50 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:25:52 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:25:52 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:25:55 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:25:55 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 166
ERROR - 2012-08-21 10:25:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 166
ERROR - 2012-08-21 10:25:55 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 166
ERROR - 2012-08-21 10:25:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 166
ERROR - 2012-08-21 10:25:55 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:25:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:25:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:26:05 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:26:05 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 166
ERROR - 2012-08-21 10:26:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 166
ERROR - 2012-08-21 10:26:05 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 166
ERROR - 2012-08-21 10:26:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 166
ERROR - 2012-08-21 10:26:05 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:27:50 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:27:50 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:27:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:27:50 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:27:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:27:50 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:28:33 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:29:23 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:29:30 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:29:34 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:29:48 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:29:48 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:29:55 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:29:55 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 168
ERROR - 2012-08-21 10:29:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 168
ERROR - 2012-08-21 10:29:55 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 168
ERROR - 2012-08-21 10:29:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 168
ERROR - 2012-08-21 10:29:55 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:32:56 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:32:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:33:01 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:33:01 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:33:50 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:33:50 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:33:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:33:50 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:33:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:33:50 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:33:54 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:33:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:35:11 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:35:22 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:35:22 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:35:37 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:35:37 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:35:46 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:35:46 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:35:47 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:35:47 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:36:06 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:36:06 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:36:31 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:36:37 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:36:37 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:38:24 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:38:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:38:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:38:24 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:38:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:38:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:38:55 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:38:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:38:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:38:55 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:38:58 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:38:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:38:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:38:58 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:39:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:39:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:40:37 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:40:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:40:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:40:37 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:10 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:10 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:18 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:18 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:32 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:32 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:41:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:41:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:41:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:41:49 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:49 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:54 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:41:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:41:54 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:42:18 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:42:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:42:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:42:18 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:42:32 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 171
ERROR - 2012-08-21 10:42:32 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:43:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:43:16 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:16 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:16 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:21 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:21 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:21 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:21 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:43:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:43:28 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:28 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:28 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:28 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:32 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:32 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:43:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:43:43 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:43:43 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:43 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:43:43 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:44:41 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:44:41 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:44:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:44:41 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:44:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:44:41 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:45:02 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:45:02 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:02 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:02 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:45:03 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:45:03 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:03 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:45:09 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:45:09 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:09 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:09 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:45:19 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:45:19 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: product_name /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: checkbox1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: date1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: datetime1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: upload1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: multicheckbox1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: multidropdown1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: radio1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: dropdown1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: textarea1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> Undefined index: wysiwyg1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:45:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: product_name /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: checkbox1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: date1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: datetime1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: upload1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: multicheckbox1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: multidropdown1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: radio1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: dropdown1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: textarea1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: wysiwyg1 /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: calendar_month /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: calendar_year /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: picture /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: description /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: location /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: event_date /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: byob /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: calendar_month /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: calendar_year /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: picture /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: description /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: location /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: event_date /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: byob /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: calendar_month /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: calendar_year /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: picture /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: description /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: location /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: event_date /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: byob /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: body /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: attached_download /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: test /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: body /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: attached_download /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: test /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: body /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: attached_download /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: test /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: body /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: attached_download /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined index: test /var/www/html/hero/app/modules/publish/models/content_model.php 767
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:45:52 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:46:01 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:46:01 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:46:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:46:01 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:46:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:46:01 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:46:17 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:46:17 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:46:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:46:17 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:46:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:46:17 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:46:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /var/www/html/hero/app/modules/publish/models/content_model.php:782) /var/www/html/hero/system/libraries/Session.php 671
ERROR - 2012-08-21 10:47:06 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:06 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:08 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:08 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:08 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:08 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:11 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:11 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:11 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:11 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:12 --> 404 Page Not Found --> product/product
ERROR - 2012-08-21 10:47:15 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:15 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:15 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:15 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:17 --> 404 Page Not Found --> product/aaa
ERROR - 2012-08-21 10:47:20 --> 404 Page Not Found --> product/product
ERROR - 2012-08-21 10:47:36 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:36 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:36 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:47:36 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:39 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:47:39 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:49:59 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/views/content_standard.php 53
ERROR - 2012-08-21 10:49:59 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/views/content_standard.php 53
ERROR - 2012-08-21 10:49:59 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/views/content_standard.php 53
ERROR - 2012-08-21 10:49:59 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/views/content_standard.php 53
ERROR - 2012-08-21 10:49:59 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/views/content_standard.php 53
ERROR - 2012-08-21 10:49:59 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/views/content_standard.php 53
ERROR - 2012-08-21 10:49:59 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/views/content_standard.php 53
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 743
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 756
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 743
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 756
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 743
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 756
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 743
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 756
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 743
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 756
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 743
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 756
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 743
ERROR - 2012-08-21 10:51:43 --> Severity: Notice  --> Undefined index: language_code /var/www/html/hero/app/modules/publish/models/content_model.php 756
ERROR - 2012-08-21 10:53:08 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:53:08 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:53:11 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:53:11 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:53:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:53:11 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:53:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:53:11 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:53:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:53:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:53:20 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:53:20 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:53:23 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:53:23 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:53:26 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:53:26 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:53:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:53:26 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:53:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 167
ERROR - 2012-08-21 10:53:26 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:54:16 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:54:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:54:45 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:54:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:54:49 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:54:49 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:54:51 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:54:51 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:54:51 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:54:51 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:54:54 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:54:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:54:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:54:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 125
ERROR - 2012-08-21 10:55:25 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:55:25 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:55:25 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:55:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 125
ERROR - 2012-08-21 10:55:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:55:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:55:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:55:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:55:58 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:55:58 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:55:58 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:55:58 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:00 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:00 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:02 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:02 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:04 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:56:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:56:04 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:07 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:22 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:22 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:25 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:25 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:26 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:56:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:56:26 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:31 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:31 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:33 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:33 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:34 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:34 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:37 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:37 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:56:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:56:41 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:41 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:43 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:43 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:43 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:56:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:56:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:56:52 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:56:52 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:57:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:57:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:57:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:05 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:05 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:57:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:57:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:57:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:57:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:57:13 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:57:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 124
ERROR - 2012-08-21 10:57:29 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:29 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:29 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:57:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 125
ERROR - 2012-08-21 10:57:34 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:37 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:57:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 125
ERROR - 2012-08-21 10:57:56 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:57:58 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:57:58 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:01 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:01 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:03 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 10:58:10 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:17 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:17 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:17 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:17 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:18 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:18 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:18 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:58:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 10:58:18 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 10:58:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 10:58:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 11:03:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:11 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 11:03:11 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 11:03:14 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 11:03:14 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 11:03:16 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:16 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:20 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:20 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:20 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 11:03:23 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 11:03:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 11:03:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 11:03:23 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 11:03:26 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:03:29 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 11:03:29 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 11:27:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:27:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:27:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 11:28:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:28:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:28:25 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:28:25 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:32:51 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:32:51 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:38:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:38:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:40:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:40:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:47:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:47:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:47:46 --> Severity: Notice  --> Undefined variable: content_id /var/www/html/hero/app/modules/publish/controllers/admincp.php 721
ERROR - 2012-08-21 11:47:47 --> Severity: Warning  --> Missing argument 1 for Admincp::edit() /var/www/html/hero/app/modules/publish/controllers/admincp.php 498
ERROR - 2012-08-21 11:47:47 --> Severity: Notice  --> Undefined variable: id /var/www/html/hero/app/modules/publish/controllers/admincp.php 500
ERROR - 2012-08-21 11:47:47 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/modules/publish/models/content_model.php 777
ERROR - 2012-08-21 11:47:47 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:47:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:47:53 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:47:53 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:48:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:48:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:48:05 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:48:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:49:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:49:11 --> Severity: Warning  --> Missing argument 1 for Admincp::edit() /var/www/html/hero/app/modules/publish/controllers/admincp.php 498
ERROR - 2012-08-21 11:49:11 --> Severity: Notice  --> Undefined variable: id /var/www/html/hero/app/modules/publish/controllers/admincp.php 500
ERROR - 2012-08-21 11:49:11 --> Severity: Notice  --> Undefined variable: custom_fields /var/www/html/hero/app/modules/publish/models/content_model.php 777
ERROR - 2012-08-21 11:49:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:49:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:49:46 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:49:53 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:49:53 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:54:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:55:24 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 11:55:27 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 11:56:32 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 11:57:31 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:57:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:58:03 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 11:58:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:00:00 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:00:00 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:03:47 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 12:03:55 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 12:03:56 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 12:04:04 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 12:04:10 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:04:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:04:15 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 12:04:16 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 12:05:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:05:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:05:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:05:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:05:49 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:49 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:49 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:49 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:49 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:49 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:49 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:52 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:05:52 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:05:52 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:52 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:52 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:52 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:52 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:52 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:05:52 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:06:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:06:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:06:21 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:06:21 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:06:21 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:06:21 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:06:21 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:06:21 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:06:21 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:07:30 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:07:30 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:07:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:07:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php:61) /var/www/html/hero/system/libraries/Session.php 671
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 12:07:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:08:20 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:08:20 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:08:20 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:20 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:20 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:20 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:20 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:20 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:20 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:22 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:08:22 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:08:22 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:22 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:22 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:22 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:22 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:22 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:22 --> Severity: Notice  --> Undefined index: df /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/relationship.php 64
ERROR - 2012-08-21 12:08:52 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:08:52 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:09:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:09:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:09:14 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:09:14 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:10:57 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:10:57 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:11:19 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:11:19 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:12:04 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:12:04 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:18:45 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:18:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:21:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:21:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:21:10 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:21:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:21:24 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:21:24 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:22:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:22:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:22:41 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:22:41 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:22:57 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:22:57 --> Severity: Notice  --> Undefined variable: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 105
ERROR - 2012-08-21 12:23:03 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:23:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:23:47 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:23:47 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:24:13 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:24:13 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:25:42 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:25:42 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:25:48 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:25:48 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:25:55 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:25:55 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:26:22 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:26:22 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:26:24 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:26:24 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:26:33 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:26:33 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:26:34 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:26:34 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:26:58 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:26:58 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:27:00 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:27:00 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:27:13 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:27:13 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$load /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 111
ERROR - 2012-08-21 12:28:08 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:28:08 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:28:16 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:28:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:28:22 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:28:22 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:28:22 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:28:22 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:30:08 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:30:08 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 112
ERROR - 2012-08-21 12:30:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 112
ERROR - 2012-08-21 12:30:08 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 115
ERROR - 2012-08-21 12:30:08 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 116
ERROR - 2012-08-21 12:30:08 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:30:08 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 112
ERROR - 2012-08-21 12:30:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 112
ERROR - 2012-08-21 12:30:08 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 115
ERROR - 2012-08-21 12:30:08 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 116
ERROR - 2012-08-21 12:30:16 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:30:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:30:26 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:30:26 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:31:37 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:31:37 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:31:43 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:31:43 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:32:02 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:32:02 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:32:04 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:32:04 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:32:35 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:32:35 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:33:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:33:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 12:35:42 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:35:42 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$smarty /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 115
ERROR - 2012-08-21 12:35:51 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:35:51 --> Severity: Notice  --> Undefined property: Embed_content_fieldtype::$smarty /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 115
ERROR - 2012-08-21 12:36:16 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:36:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:36:46 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:36:47 --> Severity: Notice  --> Undefined variable: test /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:36:47 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:36:57 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 12:36:57 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 13:36:13 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 13:36:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 14:24:39 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:24:39 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:24:42 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:24:42 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:24:50 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:24:50 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:25:06 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:25:06 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:27:39 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:27:39 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:28:06 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:28:06 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:29:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 14:29:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 14:30:16 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:30:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 14:31:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 14:31:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:02:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:02:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:02:43 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 16:02:43 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 16:08:27 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:08:27 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:09:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:09:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:11:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:11:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:11:56 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:11:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:12:00 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:12:00 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:12:26 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:12:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:14:33 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:14:33 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:16:33 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:16:33 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:16:33 --> 404 Page Not Found --> 
ERROR - 2012-08-21 16:16:34 --> 404 Page Not Found --> 
ERROR - 2012-08-21 16:16:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:16:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:16:50 --> 404 Page Not Found --> 
ERROR - 2012-08-21 16:16:51 --> 404 Page Not Found --> 
ERROR - 2012-08-21 16:18:07 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:18:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:21:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:21:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:23:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:23:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:23:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:23:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:24:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:24:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:24:52 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:24:52 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:26:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:26:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:26:30 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:26:30 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:26:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:26:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:27:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:27:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:27:32 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:27:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:27:47 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:27:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:28:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:28:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:28:25 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:28:25 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:28:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:28:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:29:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:29:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:29:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:29:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:30:27 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:30:27 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:30:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:30:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:31:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:31:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:32:58 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:32:58 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:33:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:33:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:33:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:33:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:36:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:36:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:37:34 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:37:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:38:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:38:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:38:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:38:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:39:27 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:39:27 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:39:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:39:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:39:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:39:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:41:03 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:41:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:41:28 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:41:28 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:41:35 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:41:35 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:44:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:44:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:45:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:45:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:45:26 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:45:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:45:32 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:45:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:46:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:46:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:46:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:46:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:47:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:47:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:47:27 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:47:27 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:47:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:47:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:48:08 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:48:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:48:40 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:48:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:48:51 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:48:51 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:49:10 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:49:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:49:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:49:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:53:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:53:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:53:53 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:53:53 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:54:18 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:54:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:54:25 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:54:25 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:54:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:54:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:55:08 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:55:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:55:22 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:55:22 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:55:28 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:55:28 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:56:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:56:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:57:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:57:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:58:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 16:58:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:02:22 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:02:22 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:02:47 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:02:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:04:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:04:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:05:07 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:05:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:07:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:07:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:08:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:08:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:08:43 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:08:43 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:08:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:08:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:09:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:09:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:09:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:09:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:12:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:12:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:13:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:13:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:13:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:13:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:13:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:13:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:17:29 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:17:29 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:17:46 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:17:46 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:18:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:18:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:18:41 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:18:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:18:51 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:18:51 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:19:19 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:19:19 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:19:56 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:19:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:20:34 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:20:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:21:05 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:21:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:21:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:21:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:22:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:23:26 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:23:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:23:31 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:23:31 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:23:31 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:23:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:23:31 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:23:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:24:13 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:24:13 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:24:13 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:24:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:24:13 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:24:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:25:04 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:25:04 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:25:04 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:25:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:25:04 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:25:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:25:14 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:25:14 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:25:14 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:25:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:25:14 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:25:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:25:24 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:25:24 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:25:24 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:25:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:25:24 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:25:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 160
ERROR - 2012-08-21 17:27:22 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:27:22 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:27:33 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:27:33 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:28:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:28:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:28:04 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 118
ERROR - 2012-08-21 17:28:04 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 118
ERROR - 2012-08-21 17:28:04 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 118
ERROR - 2012-08-21 17:28:04 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 118
ERROR - 2012-08-21 17:28:04 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 118
ERROR - 2012-08-21 17:28:04 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 118
ERROR - 2012-08-21 17:28:04 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 118
ERROR - 2012-08-21 17:28:04 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 118
ERROR - 2012-08-21 17:30:20 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:30:20 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:32:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:32:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:32:43 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:32:43 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:33:00 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:33:00 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:33:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:33:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:33:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:33:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:33:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:33:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:34:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:34:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:34:34 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:34:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:34:46 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:34:46 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:35:55 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:35:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:36:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:36:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:37:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:37:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:37:35 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:37:35 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:37:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:37:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:39:13 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:39:13 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:39:13 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:39:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:39:13 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:39:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:39:20 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:39:20 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:39:20 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:39:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:39:20 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:39:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:39:32 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:39:32 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 237
ERROR - 2012-08-21 17:39:32 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 237
ERROR - 2012-08-21 17:39:32 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:39:33 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:39:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:39:33 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:39:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:39:58 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:39:58 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 237
ERROR - 2012-08-21 17:39:58 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 237
ERROR - 2012-08-21 17:39:58 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:39:58 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:39:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:39:58 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:39:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:40:37 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:40:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 232
ERROR - 2012-08-21 17:40:37 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:40:37 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:40:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:40:37 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:40:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:40:45 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:40:45 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 17:40:45 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 17:40:45 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:40:45 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:40:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:40:45 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:40:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:42:29 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:42:29 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 240
ERROR - 2012-08-21 17:42:29 --> Severity: Notice  --> Undefined index: title /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 240
ERROR - 2012-08-21 17:42:29 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:42:29 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:42:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:42:29 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:42:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:42:57 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:42:57 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:42:57 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:42:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:42:57 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:42:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:43:05 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:43:05 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:43:05 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:43:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:43:05 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:43:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 17:46:49 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:46:49 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:46:49 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:46:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:47:40 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:47:40 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:47:40 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:47:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:50:35 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:50:35 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 17:50:35 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:50:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 17:52:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:52:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:52:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:52:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:53:50 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:53:50 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:54:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:54:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:54:31 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:54:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:54:51 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:54:51 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:55:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:55:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:55:08 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:55:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:59:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 17:59:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:00:01 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:00:01 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:00:01 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:00:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:00:48 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:00:48 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:00:48 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:00:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:29 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:29 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:29 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:30 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:30 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:31 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:32 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:32 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:32 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:32 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:32 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:32 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:46 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:46 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:46 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:47 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:47 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:47 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:54 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:54 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:01:54 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:01:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:01 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:01 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:01 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:07 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:07 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:07 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:08 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:08 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:08 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:16 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:16 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:17 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:17 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:17 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:34 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:34 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:02:34 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:02:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:04 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:04 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 18:03:04 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 18:03:04 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 18:03:04 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:04 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:20 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:20 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 240
ERROR - 2012-08-21 18:03:20 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 240
ERROR - 2012-08-21 18:03:20 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 240
ERROR - 2012-08-21 18:03:20 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:20 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:38 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:38 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:38 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:46 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:46 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:46 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:52 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:52 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:03:52 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:03:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 160
ERROR - 2012-08-21 18:06:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:06:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:08:41 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:08:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:09:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:09:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:09:45 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:09:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:10:20 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:10:20 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:12:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:12:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:12:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:12:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:14:32 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:14:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:15:51 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:15:51 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:17:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:17:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:19:52 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:19:52 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:22:56 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:22:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:23:26 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:23:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:23:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:23:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:24:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:24:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:05 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:13 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:25:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:26:08 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:26:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:28:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:28:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:29:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:29:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:32:29 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:32:29 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:32:43 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:32:43 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:33:38 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:33:38 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:33:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:33:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:34:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:34:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:34:54 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:34:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:35:51 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:35:51 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:36:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:36:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:40:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:40:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:41:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:41:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:41:36 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:41:36 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:42:07 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:42:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:42:09 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:42:09 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:42:58 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:42:58 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:43:06 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:43:06 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:43:18 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:43:18 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 18:46:48 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 18:47:39 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 18:48:50 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 18:49:41 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:49:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:49:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:49:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:51:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:51:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 18:52:03 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 18:52:18 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 18:52:20 --> 404 Page Not Found --> gallery1
ERROR - 2012-08-21 19:14:07 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 19:14:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 19:14:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 19:14:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 19:15:08 --> Severity: Notice  --> Undefined variable: gallery /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 19:15:09 --> Severity: Notice  --> Undefined index: month /var/www/html/hero/writeable/templates_compile/e5dd7a9d39477df9f969befdcc1ffa5813425c79.file.events.thtml.php 199
ERROR - 2012-08-21 19:15:10 --> Severity: Notice  --> Undefined index: month /var/www/html/hero/writeable/templates_compile/e5dd7a9d39477df9f969befdcc1ffa5813425c79.file.events.thtml.php 199
ERROR - 2012-08-21 19:15:18 --> 404 Page Not Found --> 
ERROR - 2012-08-21 19:16:38 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 19:16:38 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 20:03:46 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:03:46 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:27:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:27:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:37:15 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:37:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:37:52 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:37:52 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:38:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:38:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:38:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:38:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:38:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:38:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:39:34 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:39:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:40:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:40:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:40:22 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:40:22 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:40:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:40:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:48:34 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:48:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:48:34 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 99
ERROR - 2012-08-21 20:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 99
ERROR - 2012-08-21 20:50:49 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:50:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:50:49 --> Severity: Notice  --> Undefined index: field /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 100
ERROR - 2012-08-21 20:50:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 100
ERROR - 2012-08-21 20:51:08 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:51:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:51:19 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:51:19 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:51:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:51:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:58:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:58:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:59:05 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:59:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:59:58 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 20:59:58 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:43 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:43 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php:100) /var/www/html/hero/system/libraries/Session.php 671
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:00:45 --> Severity: Notice  --> Undefined index: content_type_id /var/www/html/hero/app/modules/publish/models/content_model.php 472
ERROR - 2012-08-21 21:00:46 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:01:41 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:01:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:02:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:02:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:02:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:02:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:02:56 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:02:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:03:09 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:03:09 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 223
ERROR - 2012-08-21 21:03:09 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 21:03:09 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 239
ERROR - 2012-08-21 21:03:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 21:03:09 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:03:34 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:03:34 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 223
ERROR - 2012-08-21 21:03:34 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 21:03:34 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 239
ERROR - 2012-08-21 21:03:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 21:03:34 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:03:38 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:03:38 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 223
ERROR - 2012-08-21 21:03:38 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 21:03:38 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 239
ERROR - 2012-08-21 21:03:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 21:03:38 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:04:20 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:04:20 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:05:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:05:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:06:05 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:06:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:06:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:06:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:06:57 --> 404 Page Not Found --> 
ERROR - 2012-08-21 21:06:57 --> 404 Page Not Found --> 
ERROR - 2012-08-21 21:09:03 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:09:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:11:47 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:11:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:12:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:12:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:13:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:13:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:14:01 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:14:01 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:14:03 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:14:03 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 223
ERROR - 2012-08-21 21:14:03 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 21:14:03 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 239
ERROR - 2012-08-21 21:14:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:17:08 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:17:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:17:37 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:17:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:18:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:18:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:18:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:18:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:19:17 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:19:17 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:19:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:19:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:19:57 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:19:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:21:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:21:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:21:56 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:21:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:22:18 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:22:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:22:28 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:22:28 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:22:58 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:22:58 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:23:28 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:23:57 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:23:57 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:24:00 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:24:00 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 223
ERROR - 2012-08-21 21:24:00 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 21:24:00 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 239
ERROR - 2012-08-21 21:24:00 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:24:03 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:24:03 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 223
ERROR - 2012-08-21 21:24:03 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 21:24:03 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 239
ERROR - 2012-08-21 21:24:03 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 21:24:24 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:24:24 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:27:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:27:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:27:02 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 143
ERROR - 2012-08-21 21:27:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 143
ERROR - 2012-08-21 21:27:02 --> Severity: Notice  --> Undefined variable: url /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 126
ERROR - 2012-08-21 21:27:02 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 143
ERROR - 2012-08-21 21:27:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 143
ERROR - 2012-08-21 21:27:02 --> Severity: Notice  --> Undefined variable: url /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 126
ERROR - 2012-08-21 21:27:02 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 143
ERROR - 2012-08-21 21:27:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 143
ERROR - 2012-08-21 21:27:02 --> Severity: Notice  --> Undefined variable: url /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 126
ERROR - 2012-08-21 21:27:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:27:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:27:21 --> Severity: Notice  --> Undefined variable: url /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 126
ERROR - 2012-08-21 21:27:21 --> Severity: Notice  --> Undefined variable: url /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 126
ERROR - 2012-08-21 21:27:21 --> Severity: Notice  --> Undefined variable: url /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/embed_content.php 126
ERROR - 2012-08-21 21:28:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:28:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:30:18 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:30:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:30:54 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:30:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:33:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:33:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:33:25 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:33:25 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:33:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:33:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:34:30 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:34:30 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:35:03 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:35:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:35:18 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:35:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:35:31 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:35:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:35:58 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:35:58 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:36:27 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:36:27 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:36:52 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:36:52 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:44:48 --> Severity: Notice  --> Undefined variable: default /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 283
ERROR - 2012-08-21 21:44:52 --> Severity: Notice  --> Undefined variable: default /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 283
ERROR - 2012-08-21 21:45:21 --> Severity: Notice  --> Undefined index: max_files /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 276
ERROR - 2012-08-21 21:45:35 --> Severity: Notice  --> Undefined index: max_files /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 276
ERROR - 2012-08-21 21:49:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:49:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:50:18 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:50:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:51:40 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:51:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:51:45 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:51:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:53:26 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:53:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:54:35 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:54:35 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:54:43 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:54:43 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:55:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:55:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 21:59:15 --> Severity: Notice  --> Undefined variable: required /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 276
ERROR - 2012-08-21 21:59:34 --> Severity: Notice  --> Undefined index: multi_files /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 276
ERROR - 2012-08-21 21:59:49 --> Severity: Notice  --> Undefined index: multi_files /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 276
ERROR - 2012-08-21 22:00:04 --> Severity: Notice  --> Undefined index: multi_files /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 277
ERROR - 2012-08-21 22:02:16 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 22:02:16 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 223
ERROR - 2012-08-21 22:02:16 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 238
ERROR - 2012-08-21 22:02:16 --> Severity: Notice  --> Uninitialized string offset: 0 /var/www/html/hero/writeable/templates_compile/79fd77b04f512980f040685da26d3731ab0844ac.file.content.thtml.php 239
ERROR - 2012-08-21 22:02:16 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 159
ERROR - 2012-08-21 22:02:16 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 22:02:19 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:02:19 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:02:19 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 22:02:37 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:02:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:02:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 13 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/table.php 102
ERROR - 2012-08-21 22:03:22 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:03:22 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:05:52 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:05:52 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:05:52 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 123
ERROR - 2012-08-21 22:05:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 123
ERROR - 2012-08-21 22:06:12 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:06:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:06:12 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 122
ERROR - 2012-08-21 22:06:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 122
ERROR - 2012-08-21 22:06:32 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:06:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:07:06 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:07:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:08:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:08:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:08:40 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:08:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:10:03 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:10:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:10:16 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:10:16 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:10:52 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:10:52 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:12:13 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:12:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:12:35 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:12:35 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:13:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:13:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:16:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:16:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:16:09 --> Severity: Notice  --> Undefined index: multi_files /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/gallery.php 113
ERROR - 2012-08-21 22:16:26 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:16:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:17:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:17:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:17:45 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:17:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:19:32 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:19:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:19:44 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:19:44 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:20:02 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:20:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:20:21 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:20:21 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:21:32 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:21:32 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:22:25 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:22:25 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:26:41 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:26:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:27:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:27:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:29:23 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:29:23 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:29:36 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:29:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:29:41 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:29:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:29:58 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:29:58 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:30:19 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:30:19 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:30:27 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:30:27 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:30:42 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:30:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:31:01 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:31:01 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:31:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:31:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:31:43 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:31:43 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:32:17 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:32:17 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:32:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:32:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 22:33:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 172
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 22:33:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 172
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 22:33:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 172
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined index: path /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 22:33:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 167
ERROR - 2012-08-21 22:33:07 --> Severity: Notice  --> Undefined variable: content /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/file_list.php 172
ERROR - 2012-08-21 22:33:10 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:33:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:33:13 --> Severity: Notice  --> Undefined variable: body /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 22:33:13 --> Severity: Notice  --> Undefined variable: values /var/www/html/hero/app/libraries/smarty/sysplugins/smarty_internal_data.php 287
ERROR - 2012-08-21 22:33:16 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:33:16 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:33:35 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:33:35 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:33:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:33:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:34:47 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:34:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:36:04 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:36:04 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:38:16 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:38:16 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:38:38 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:38:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:41:26 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:41:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:41:59 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:41:59 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:43:13 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:43:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:44:48 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:44:48 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:44:56 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:44:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:45:18 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:45:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:46:11 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:46:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:47:07 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:47:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:58:47 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:58:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:58:53 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:59:03 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:59:03 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 22:59:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:46:03 --> Severity: Warning  --> Missing argument 1 for Admincp::copypage() /var/www/html/hero/app/modules/publish/controllers/admincp.php 1168
ERROR - 2012-08-21 23:46:03 --> Severity: Warning  --> Missing argument 2 for Admincp::copypage() /var/www/html/hero/app/modules/publish/controllers/admincp.php 1168
ERROR - 2012-08-21 23:46:03 --> Severity: Notice  --> Undefined variable: contents /var/www/html/hero/app/modules/publish/controllers/admincp.php 1172
ERROR - 2012-08-21 23:46:03 --> Severity: Notice  --> Undefined variable: return_url /var/www/html/hero/app/modules/publish/controllers/admincp.php 1173
ERROR - 2012-08-21 23:46:24 --> Severity: Warning  --> Missing argument 1 for Admincp::copypage() /var/www/html/hero/app/modules/publish/controllers/admincp.php 1168
ERROR - 2012-08-21 23:46:24 --> Severity: Warning  --> Missing argument 2 for Admincp::copypage() /var/www/html/hero/app/modules/publish/controllers/admincp.php 1168
ERROR - 2012-08-21 23:46:24 --> Severity: Notice  --> Undefined variable: contents /var/www/html/hero/app/modules/publish/controllers/admincp.php 1172
ERROR - 2012-08-21 23:46:24 --> Severity: Notice  --> Undefined variable: return_url /var/www/html/hero/app/modules/publish/controllers/admincp.php 1173
ERROR - 2012-08-21 23:47:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:47:18 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:52:47 --> Severity: Notice  --> Undefined index: type /var/www/html/hero/app/modules/publish/controllers/admincp.php 1177
ERROR - 2012-08-21 23:52:51 --> Severity: Notice  --> Undefined index: type /var/www/html/hero/app/modules/publish/controllers/admincp.php 1177
ERROR - 2012-08-21 23:53:29 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:54:07 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:54:09 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:54:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:54:13 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:54:39 --> Severity: Warning  --> unserialize() expects parameter 1 to be string, array given /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:54:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:54:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:55:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:55:49 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:56:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:58:34 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:58:39 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
ERROR - 2012-08-21 23:58:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 1 bytes /var/www/html/hero/app/modules/custom_fields/libraries/fieldtypes/multicheckbox.php 60
