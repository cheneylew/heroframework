		<div id="footer">
			Copyright &copy; <?=date('Y');?>, <a href="http://www.electricfunction.com">Electric Function, Inc</a>.  All Rights Reserved.
		</div>
	</div>
</body>
</html>