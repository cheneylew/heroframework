<?=$this->load->view(branded_view('cp/header'));?>

<h1>Install Complete!</h1>

<p>Your new theme was installed successfully.  <a target="_blank" href="<?=site_url();?>">Click here to view your homepage</a>.</p>

<?=$this->load->view(branded_view('cp/footer'));?>