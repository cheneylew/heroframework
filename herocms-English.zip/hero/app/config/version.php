<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* Version Config
*
* Defines the latest version of the app.  Do not modify (except when upgrading), or your risk executing update scripts
* at an improper time.
*/

$config['app_version'] = '3.76';