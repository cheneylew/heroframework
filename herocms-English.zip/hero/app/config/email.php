<?php

$config['protocol'] = 'mail';
$config['wordwrap'] = TRUE;
$config['validate'] = TRUE;